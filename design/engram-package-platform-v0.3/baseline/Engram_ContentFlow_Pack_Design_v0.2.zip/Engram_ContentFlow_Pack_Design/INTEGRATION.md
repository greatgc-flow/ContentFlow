# Integration and migration plan — AI first, ContentFlow second

## Verified baseline

Main 3.11.13 at `61076a4734d691fe917bee562a2e2bec9c7a9148` includes generic tool catalogs, single default Python/venv, dispatcher, update/repair/relocate, backup/reset and detached uninstall. AI Rev06 at `c59c0e42bb6584bc873269b7128a1c94ecba3229` already proposes `_sys/AI`, a thin `ai` CLI, shared lifecycle, Multi-Python, installed/absent marker, immutable model/DB generations, local-first permissions. WP0 branch at `50d3ddd19a1fed292080266c233f70e5bf52ef03` records verified standard-user native Python/wheel probes and cross-volume offline rebuild; registry transactions, AI profiles, GPU, PG and production safety remain unproven. Preserve historical evidence; do not imply implemented AI. Check current refs before modifying anything. Existing product scope says portable Windows dev environment, not generic domain functionality; owner-approved package manager extends environment provisioning only, not domain scope.

## Crosswalk: do not rewrite AI Rev06

| AI design | Generalize now | Keep inside AI |
|---|---|---|
| SPEC §§3–4, ADR-01/17/21–29 | Trusted slot, independent CLI, Multi-Python, child env, reference-aware runtime transactions | `_sys/AI`, Hermes/OpenClaw/Hindsight compatibility and memory provider choices |
| SPEC §5.1–5.4, ADR-18 | Installed-state probe, plan/approval, coordinator, parent/child receipts, recovery, shared artifact verification and backup envelope | Native DB backup, model/index compatibility, service DAG, model promotion and source consent |
| SPEC §6, ADR-44 | Minimal shared host GPU lease and drain | AI context limits, sleep scheduler, memory consolidation |
| CONTRACTS §8 | common pack CLI; preserve `ai` and `engram python` | AI commands, model-specific controls |
| WP1–3 | existing extra-runtime RED/GREEN and native proof, reuse rather than duplicate | none beyond AI consumer fixtures |
| WP4 | split into generic coordinator and AI adapter; test fake second package first | AI profile, models, agent and memory integrations |

## ContentFlow baseline overlay (normative only for Engram integration)

| Original | Integrated decision |
|---|---|
| README independent ZIP and optional Engram | Engram-managed Windows package is primary delivery; ContentFlow domain remains independent of Engram imports, so standalone/Linux/worker can remain future delivery options. |
| Docs 02/05 separate CLI | Direct `contentflow` wrapper from Engram `_sys/cli`, same domain commands; setup/repair/update/remove delegate to common coordinator. No standalone root launchers in integrated package. |
| Docs 08/14 portable layout and runtime packs | `_sys/ContentFlow` owns app/config/workspaces/models/packs; reuse compatible shared Python/Node/FFmpeg, per-app venv and runtime locks. No redundant portable Python copy unless justified vendor exception. |
| Docs 14 pack manifests | Existing `pack_manifest.schema.json` is the app's internal media/model pack contract. Common descriptor governs application installation, not a replacement schema; use namespaced component IDs and avoid dual authoritative registry. Internal selected subpack plan participates as child effects. |
| Docs 11 / TDD_HANDOFF no Engram modifications | Only approved generic lifecycle extension belongs in Engram; no ContentFlow-specific logic in Engram core. Domain TDD may run in parallel in isolated repo/workspace, integration release blocked on common manager and AI regression. |
| Standalone Windows + Linux P0 | Managed Windows standard-user integration becomes first distribution gate. Linux standalone/remote worker retain contracts, separate certification; do not claim Linux delivered by Windows Engram. Preserve standalone offline core tests on available supported host. |
| CF-078–090 and D4 portable acceptance | Existing portable test IDs remain; evaluate through managed host and explicitly record which standalone/worker tests are deferred or not applicable by mode. Never silently mark PASS. |

## Phases and stop gates

A. Recheck remote branches and active work, compare WP0 ledger and locks; reconcile overlap with existing Work session. No parallel implementation of registry in separate branches. Keep main untouched. Design branch `design/optional-pack-platform-20261128` proposed (not created).

B. WP1–3: existing Multi-Python RED sequence, stable default compatibility, isolated venv, exact pin, offline move/recovery. Build on successful WP0 provider proof, not assume full acceptance. Add only generic runtime interface required by a second consumer. Gate: full legacy suite and installed artifact test on supported Windows, failure rollback, no host changes.

C. WP4a common package manager: immutable trusted descriptor, registry ownership and state, pure planner, fake alpha/beta packages, command/flag compatibility, shared runtime refs, journal, backup/remove, absent no-op. No native AI or video dependencies needed. Gate: PM P0 tests, staged crash injection, self-update and clean install, legacy backup archive and whole uninstall data protection.

D. WP4b AI adapter: preserve Rev06 profiles, direct `ai`, local native components conditional on original WP0 gates. Validate old AI design semantics, absent and partial states, model rollback/DB safety; do not wait for GPU/memory full profile to prove basic shared contracts. No existing PeerHub DB initialization. AI-specific tests remain independent.

E. CF integration: independent ContentFlow offline domain vertical slice with owned fixture, CPU FFmpeg, SQLite, export only. Add trusted descriptor and Lite profile, `contentflow` CLI, app adapter, lock and FFmpeg binary qualification. Gate: existing ContentFlow P0 tests applicable to managed Windows, CFI tests, AI absent/installed regression, clean standard-user Windows and offline relocation. AI is not required. ContentFlow Studio/Voice/GPU optional, mutually safe GPU lease once actual GPU needed. WebUI loopback only. No real external APIs, accounts, publishing, billable calls or GPU download without approval.

F. Third-package proof: synthetic gamma descriptor+adapter without modifying core; same lifecycle. Require only the generic features demonstrated by AI/ContentFlow/fake pack. Reject speculative marketplace, service mesh, full scheduler. Document limitations for future packages. Release only after owner decision and actual evidence.

## Ownership and sequencing

Common Engram work owns registry, install lifecycle and runtime/lease primitives. AI work owns memory-specific implementation and keeps existing branch evidence. ContentFlow code can be independent distribution repository or separate source subtree with portable app artifact; repository location is not the same as install layout. Recommend separate ContentFlow source repo and trusted package adapter/manifest in Engram (no new repo created). If owner selects monorepo instead, maintain independent tests/locks/release units. Keep app code import-free of Engram internals; adapter is composition boundary. Existing PeerHub and PortaKit remain unchanged.

## Quality gate

Every requirement must link to tests with Given/When/Then. Run core legacy, no-pack, AI-only, CF-only, both, third synthetic, partial/corrupt and old-version upgrade combinations. Pairwise axes plus explicit high-risk crosses: detached update × two installed packs × crash; shared Python update × incompatible consumer × old pin; relocation × active DB × missing offline cache; uninstall × retained external workspace × snapshot failure; clone × copied approval × remote pending effect; GPU lease × orphaned process × PID reuse; package removal × shared models/runtime; untrusted archive × path escape; new package × legacy `--only packages`. Measure root/env/registry footprint, file/DB hashes, external-effect counters, exact executable and exit codes. Status values PASS/FAIL/BLOCKED/NOT_RUN with actual receipts only. Do not certify production Windows, 3060 performance, or full package lifecycle from static schema checks.
