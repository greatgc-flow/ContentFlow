# Engram Optional Package Platform + ContentFlow — pre-TDD integration amendment v0.2

2026-11-28 KST | Design only | No repository changes, executable package, installation, provider usage or production tests.

## 시작하기

기존 Engram Local AI Rev06의 공통 수명주기와 Multi-Python 설계를 일반화한다. AI와 ContentFlow는 별도 선택형 패키지이며 서로 설치를 강제하지 않는다. Engram은 실행 환경, 등록, 버전, 안전한 설치/이동/복구/제거만 담당한다. 기존 ContentFlow v0.1.0의 도메인 설계는 변경하지 않고 설치·통합 방식에만 이 개정안을 적용한다. 기존 Engram 명령 및 사용자 데이터는 보존한다. 이 패키지는 GitHub에 커밋된 것이 아니다.

## Reading order and authority

1. [ARCHITECTURE.md](ARCHITECTURE.md): common lifecycle, runtime, resource and package boundary.
2. [INTEGRATION.md](INTEGRATION.md): integration deltas and phased implementation, AI compatibility, ContentFlow adoption.
3. [planning/REQUIREMENTS.csv](planning/REQUIREMENTS.csv), [planning/TEST_CATALOG.csv](planning/TEST_CATALOG.csv): new requirements and unexecuted acceptance specifications.
4. [contracts/package_descriptor.schema.json](contracts/package_descriptor.schema.json), [examples](examples/): structural descriptor fixtures; not installable manifests or authorization.
5. [planning/WORK_HANDOFF.md](planning/WORK_HANDOFF.md): parallel work and branch reconciliation.
6. [planning/SOURCES.md](planning/SOURCES.md): pinned remote evidence and unresolved proof.
7. `baseline/ContentFlow_PreTDD_Design_v0.1.0.zip`: untouched historical design, 90 requirements, 180 planned tests. SHA-256 `f7b8592abce66d9c9b25c3613c61e239f1e8ad318cdc11452ddaa5a04c7ca097`.

Authority: existing Engram main behavior and user data safety remain non-negotiable; this proposal supersedes deployment-specific statements in the historical ContentFlow baseline only where enumerated in INTEGRATION. Existing AI Rev06 remains immutable, with additive crosswalk here. New PM/CFI IDs do not replace historical R/T/CF IDs. Implementers must recheck current remote commits before RED. Neither JSON validation nor traceability implies working software.
