# Optional Package Platform — normative design proposal

## 1. Scope and architecture decision

Use a minimal, declarative lifecycle extension of Engram, not a generic application operating system. The original AI Rev06 common coordinator and runtime registry are the starting point. Engram owns acquisition, verification, ownership, runtime binding, launch environment, lifecycle plan/journal, and reporting; packages own their domain schemas, app commands, services, model selection, migrations and data semantics. Preserve the generic tool catalog; do not conflate an AI CLI, pip distribution, application package, runtime build or internal model pack. External apps and PeerHub remain references unless explicitly managed under a new reviewed descriptor. No mandatory AI dependency for ContentFlow. No changes to Engram's default Python/venv semantics. One coordinator; no per-package duplicate installer. No marketplace, remote auto-discovery, dependency solver for arbitrary third-party packages, container orchestration or hosted control plane in P0.

```text
Engram/
  Engram.exe, engram.cmd           existing root unchanged
  .engram/, workspace/             existing user state
  _sys/
    core/                          existing + minimal coordinator seams
    cli/{engram,ai,contentflow}.cmd  thin wrappers, no new root launcher
    defaults/packages/             reviewed descriptor templates/catalog (static)
    data/state/                    package registry + parent lifecycle journal
    data/setup-files/              managed artifact cache (verified)
    env/python/, env/venv/         legacy default unchanged
    env/python-versions/           shared builds from AI WP1–3
    env/python-envs/<owner>/       separate application environments
    env/...                        other compatible registered runtime builds
    AI/                            preserve approved AI layout and case
      core/, defaults/, apps/, runtime/, models/, config/, data/, state/ ...
    ContentFlow/                   independent managed package
      app/, defaults/, packs/, config/, workspaces/, models/, state/, logs/ ...
    packages/<id>/                 proposed default slot for future packages
```

Canonical IDs are lowercase ASCII (`ai`, `contentflow`); physical slots are an explicit trusted catalog mapping, not concatenation of untrusted input. Protect reserved Engram roots and detect case-insensitive collisions and reparse/UNC escapes. `AI` and `ContentFlow` are explicit compatibility slots; do not move AI just to normalize names. Catalog descriptors are static metadata and do not constitute installation. Installed marker binds installation ID, package ID, exact generation, manifest digest, state, root and owned assets. An absent descriptor must not create directories, check remote metadata, import package code or start services during normal Engram commands. Unknown/corrupt/collision states are reported and never automatically adopted. No broad scanning or arbitrary script discovery. Future additions require a reviewed descriptor and a contract test, not package-specific branches in core.

## 2. Common package contract

| Type | Authority / effect |
|---|---|
| Catalog descriptor | Reviewed identity, slot, supported host, profiles, capability/dependency declarations, lifecycle adapter protocol, entrypoint names; no secrets or remote executable hook strings |
| Release manifest | Exact trusted publisher, immutable artifact bytes/digest, dependencies/lock, license/SBOM, size, compatibility, per-file ownership, provenance and signature verification; separate from descriptor fixture |
| Installed registry | installation UUID, registry revision, selected profile, generation/pointers, runtime bindings, ownership set, health evidence, prior generation and pending receipts |
| Package adapter | A trusted, pinned, out-of-process entrypoint implementing a versioned request/response protocol; validate before launch. Do not import arbitrary package modules into core. Adapter not a security sandbox. |
| Package data | Separate durable state, app DB, source/artifact rights, package migration logic; coordinator only requests a consistent checkpoint. |
| Resource lease | Host-scoped shared GPU admission if two managed consumers coexist; package-owned queue and bounded drain. Shared identity does not imply shared writable model directory. |

Lifecycle adapter minimum operations: `inspect`, `plan`, `stage`, `verify`, `quiesce`, `apply`, `health`, `rollback`, `snapshot`, `restore`, `relocate`, `cleanup`, `resume`. Hooks are capability-scoped; unsupported mandatory operation blocks that plan. Pure inspect/plan cannot download, mutate files, start services or touch private data. Explicit metadata check may fetch only approved metadata, with offline mode and stale/unknown reporting. A package-specific step may use its own app logic, but all package mutations use the same coordinator. No shell string concatenation. Use explicit trusted executable, argv, cwd, bounded stdout/stderr, timeout, process identity, request schema validation and redaction. Unknown schema major or malformed response fails closed. Synthetic adapters first; protocol is a proposed contract, not existing code. No automatic remote entrypoints; future external catalogs require separate trust review.

Minimum request: `protocol_version, op_id, parent_op_id, package_id, installation_id, root_identity, registry_revision, operation, plan_digest, policy_revision, approved_scope, deadline, current_generation, target_generation, relative_paths`. Response: `status, phase, op_id, package_id, observed_generation, effect_receipt, owned_processes, findings, next_action`. Responses cannot grant approval. Root/ownership validated by coordinator independently of adapter. Raw secrets never passed in JSON; use approved local secret reference mechanism.

## 3. Lifecycle and transactions

Detection: ABSENT / INSTALLED / PARTIAL / UNKNOWN / CORRUPT / LEGACY_COLLISION. Health is independent (HEALTHY / DEGRADED / BLOCKED / NOT_CHECKED; intentionally stopped can be healthy). Operation state: PLAN → APPROVED → STAGED → VERIFIED → DRAINED → APPLYING → COMMITTED → HEALTHY → COMPLETE. Rollback/recovery branch from appropriate phase, with explicit effect evidence; never report rolled back if publication already occurred without proof. `PARTIAL` denotes independently committed group(s) plus failure; `RECOVERY_REQUIRED` means state cannot safely proceed. Hold global lifecycle lock then registry, package/service locks in canonical ID order, short domain DB transactions last; no network call while a DB transaction held; no GPU lease while waiting on dependency. Do not acquire earlier lock while holding later. Durable parent journal persists before detached self-update; resume validates install identity, generation, scope, digest, approval and actual effects. Recompute plan and require new approval after changes. Preview produces no durable side effects (explicit metadata check uses existing cache semantics). Stage at final unique unpublished path, avoid renaming venv; verify provenance and space for stage + previous + backup + temp, drain only proven owned processes, switch registry pointers atomically, validate post-commit health; retain previous recoverable generation. No arbitrary kill by PID/name. Package A may fail without corrupting B; related shared-runtime consumer group must be coherent, no false global success.

| Engram command | Common package behavior (installed only) |
|---|---|
| `update`, `update --check`, `--dry-run` | Safe compatible updates in installed scopes; metadata only in explicit checks; do not auto-install absent packs or optional profiles |
| `doctor` | Offline, read-only bounded diagnostics; report missing runtime/corrupt marker/driver/port without starting a service or inference |
| `repair`, `relocate` | Existing preview/apply flags; exact rebuild from verified local locks/cache, reissue wrappers; no host fallback or implicit upgrades |
| `backup`, `restore`, `snapshots` | Consistent domain checkpoint via adapter; inventory/manifest/hash, verify restore. Legacy archive without package does not change it. Restore to absent package is data-only until separately installed. |
| `tidy` | Reference-aware GC of owned disposable files; protect active/pinned/previous/recovery/backup/unknown consumers |
| `reset` | Existing legacy personal data scope unchanged. Explicit pack-scoped data purge only with separate confirmation and verified backup. |
| `uninstall` | Pack remove releases owned program/runtime refs, preserves data/models by default. Existing whole-tree Engram uninstall requires preflight and verified export outside doomed tree for package data, or explicit approved purge; refuse otherwise. |

Backup cut: fence app writers, use supported DB-specific snapshots (SQLite backup/checkpoint, PG native consistency); do not copy live WAL/PG files. Include generation, schema, locks, immutable object inventory, unresolved external intents. Exclude credentials/tokens/login state by default; restore/copy never transfers authority to publish, spend, bot dispatch or auto-run. Resume prior allowed processes only. Full-tree move quiesced on local supported storage; clone creates new identity and disabled automatic jobs. External workspaces are references, never deletion targets. Cross-volume move uses verified copy and separate activation, preserve source until target health verified. Missing offline wheel/model leaves affected capability blocked; no silent download. Existing uninstall cannot preserve data inside a deleted root by assertion; the external destination and verified hash/restore receipt are required.

## 4. Runtime and hardware resource sharing

Generalize Multi-Python first, exactly preserving legacy default. Runtime identity = provider + exact version + ABI + arch + flavor + artifact digest; consumer constraints, compatibility probe and license determine sharing. Separate venv/npm lock per app. No global pip, shared site-packages, parent PATH/HOME modifications, automatic latest, host Python fallback or automatic cross-minor update. Node, FFmpeg, browser and other runtime providers are added only when a consumer proves need; no forced migration of existing generic tools. Runtime update builds immutable candidate and independent consumer environments; exact pins keep old generation. Reference-aware remove/GC protects all bound consumers and unknown ownership. Vendor-pinned private runtime allowed only as reviewed exception.

ContentFlow and AI may share compatible binaries and read-only immutable model blobs with exact digest, license and access-domain compatibility. Native stores that do not support sharing retain separate ownership. FFmpeg is a new candidate registry capability, not assumed to exist. On 3060 start with serial GPU admission across managed consumers, CPU fallback only explicitly configured and equivalent quality constraints. A single host-level resource lease includes owner, PID and process creation time, generation, heartbeat, exclusive resource claim, deadline and fencing token; abandoned lease reclaimed only after ownership/liveness validation. No default always-on broker, scheduler or OS service; use minimal shared lease primitive, evolve to supervisor only after measured need. External unmanaged GPU jobs cannot be forcibly controlled; detect/probe and defer. NVIDIA drivers remain host prerequisites; no driver installs. Budget/disk/egress consent are still independently enforced by each application; pack lifecycle cannot grant publishing, source ingestion or spend approval.

## 5. CLI proposal

Preserve `engram update --only packages` (Python packages), `--only python`, existing exit/help contracts and `ai` direct CLI. Proposed new common namespace: `engram pack list`, `info ID`, `doctor ID`, `check [ID]`, `install ID --profile PROFILE --dry-run`, `install ID --profile PROFILE --apply --yes`, `update [ID]`, `repair ID`, `remove ID`, `backup ID`, `restore ID`, `rollback ID`. Mutators preview by default or follow existing interactive confirmation policy; unattended apply explicit; risk approval separate from `--yes`. Optional scope `engram update --only pack:contentflow` only after parser/regression tests; never reinterpret current selectors. Direct `ai setup` and `contentflow setup` delegate to coordinator; normal app commands call package application under own pinned runtime. Missing pack command reports `NOT_INSTALLED` and explicit setup help, no implicit install. Exact argv and exit status forwarded; no root launcher. JSON results versioned, bounded and redacted. No remote automatic execution or public service endpoints. UI uses same commands/use cases; localhost only and no automatic browser process before launch.
